#pragma once

#if defined (_WIN32)
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

#if defined (__amigaos4__)
#include <mgl/gl.h>
#elif defined (__APPLE__)
#include <OpenGL/gl.h>
#else
#include <GL/gl.h>
#endif

#include <string>

#include "../color.hpp"
#include "../platform.hpp"
#include "../image.hpp"

namespace gcn
{
    class GCN_EXTENSION_DECLSPEC OpenGLImage : public Image
    {
    public:
        OpenGLImage(const unsigned int* pixels, int width, int height, bool convertToDisplayFormat = true);
        OpenGLImage(GLuint textureHandle, int width, int height, bool autoFree);
        virtual ~OpenGLImage();
        virtual GLuint getTextureHandle() const;
        virtual int getTextureWidth() const;
        virtual int getTextureHeight() const;
        virtual void free();
        virtual int getWidth() const;
        virtual int getHeight() const;
        virtual Color getPixel(int x, int y);
        virtual void putPixel(int x, int y, const Color& color);
        virtual void convertToDisplayFormat();

    protected:
        GLuint mTextureHandle;
        unsigned int* mPixels;
        bool mAutoFree;
        int mWidth;
        int mHeight;
		int mTextureWidth;
		int mTextureHeight;
    };
}
