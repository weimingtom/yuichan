package com.iteye.weimingtom.guichan.listener;

import com.iteye.weimingtom.guichan.event.MouseEvent;

public interface MouseListener {
	public void mouseEntered(MouseEvent mouseEvent);
    public void mouseExited(MouseEvent mouseEvent);
	public void mousePressed(MouseEvent mouseEvent);
	public void mouseReleased(MouseEvent mouseEvent);
	public void mouseClicked(MouseEvent mouseEvent);
	public void mouseWheelMovedUp(MouseEvent mouseEvent);
	public void mouseWheelMovedDown(MouseEvent mouseEvent);
    public void mouseMoved(MouseEvent mouseEvent);
    public void mouseDragged(MouseEvent mouseEvent);
}
