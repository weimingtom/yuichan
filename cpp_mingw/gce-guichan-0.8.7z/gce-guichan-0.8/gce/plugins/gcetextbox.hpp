
#ifndef GCE_TEXTBOX_HPP
#define GCE_TEXTBOX_HPP

class gceTextBox : public gcn::TextBox
{
	public:
	void draw(gcn::Graphics* g);
	
}; 

#endif // end GCE_TEXTBOX_HPP
