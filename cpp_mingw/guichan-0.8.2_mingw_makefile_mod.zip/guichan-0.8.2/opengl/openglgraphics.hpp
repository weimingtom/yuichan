#pragma once

#include "../color.hpp"
#include "../graphics.hpp"
#include "../platform.hpp"

namespace gcn
{
    class GCN_EXTENSION_DECLSPEC OpenGLGraphics: public Graphics
    {
    public:
		using Graphics::drawImage;
		
		OpenGLGraphics();
		OpenGLGraphics(int width, int height);
		virtual ~OpenGLGraphics();
        virtual void setTargetPlane(int width, int height);
        virtual void _beginDraw();
        virtual void _endDraw();
        virtual bool pushClipArea(Rectangle area);
        virtual void popClipArea();
        virtual void drawImage(const Image* image,
                               int srcX,
                               int srcY,
                               int dstX,
                               int dstY,
                               int width,
                               int height);
        virtual void drawPoint(int x, int y);
        virtual void drawLine(int x1, int y1, int x2, int y2);
        virtual void drawRectangle(const Rectangle& rectangle);
        virtual void fillRectangle(const Rectangle& rectangle);
        virtual void setColor(const Color& color);
		virtual const Color& getColor() const;

    protected:
        int mWidth, mHeight;
		bool mAlpha;
        Color mColor;
    };
}
