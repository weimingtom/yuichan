package com.iteye.weimingtom.guichan.listener;

import com.iteye.weimingtom.guichan.event.KeyEvent;

public interface KeyListener {
    public void keyPressed(KeyEvent keyEvent);
    public void keyReleased(KeyEvent keyEvent);
}
