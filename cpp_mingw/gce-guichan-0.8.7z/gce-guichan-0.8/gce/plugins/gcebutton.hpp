
#ifndef GCE_BUTTON_HPP
#define GCE_BUTTON_HPP



class gceButton : public gcn::Button
{
    public:
    void draw(gcn::Graphics *g);
};

#endif // end GCE_BUTTON_HPP

