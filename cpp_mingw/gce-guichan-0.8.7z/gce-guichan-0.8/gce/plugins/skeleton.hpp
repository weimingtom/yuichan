
#ifndef GCE_SKELETON_HPP
#define GCE_SKELETON_HPP


// should extend the actual widget you are wrapping not gcn::Widget

class gceSkeleton : public gcn::Widget
{
    public:
    void draw(gcn::Graphics *g);
};

#endif // end GCE_SKELETON_HPP

