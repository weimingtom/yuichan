#pragma once

#include "../sdl/sdlimageloader.hpp"
#include "../exception.hpp"
#include "openglimage.hpp"

namespace gcn
{
    class Image;
    
    class OpenGLSDLImageLoader : public SDLImageLoader
    {
    public:
        virtual Image* load(const std::string& filename,
                            bool convertToDisplayFormat = true)
        {
            SDL_Surface *loadedSurface = loadSDLSurface(filename);

            if (loadedSurface == NULL)
            {
                throw GCN_EXCEPTION(
                        std::string("Unable to load image file: ") + filename);
            }

            SDL_Surface *surface = convertToStandardFormat(loadedSurface);
            SDL_FreeSurface(loadedSurface);

            if (surface == NULL)
            {
                throw GCN_EXCEPTION(
                        std::string("Not enough memory to load: ") + filename);
            }
            OpenGLImage *image = new OpenGLImage((unsigned int*)surface->pixels,
                                                 surface->w,
                                                 surface->h,
                                                 convertToDisplayFormat);
            SDL_FreeSurface(surface);
            return image;
        }
    };
}
