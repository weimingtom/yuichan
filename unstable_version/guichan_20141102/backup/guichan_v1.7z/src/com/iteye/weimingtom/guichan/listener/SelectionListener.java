package com.iteye.weimingtom.guichan.listener;

import com.iteye.weimingtom.guichan.event.SelectionEvent;

public interface SelectionListener {
	public void valueChanged(SelectionEvent event);
}
