#pragma once

#include <string>

#include "actionevent.hpp"
#include "platform.hpp"

namespace gcn
{
    class GCN_CORE_DECLSPEC ActionListener
    {
    public:
		virtual ~ActionListener() { }
		virtual void action(const ActionEvent& actionEvent) = 0;
		
    protected:
        ActionListener() { }
    };
}
