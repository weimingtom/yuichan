
#ifndef GCE_CONTAINER_HPP
#define GCE_CONTAINER_HPP

class gceContainer : public gcn::Container 
{
	public:
	void draw(gcn::Graphics* g);
	
}; 

#endif // end GCE_TEXTFIELD_HPP
