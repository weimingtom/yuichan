#pragma once

#include <string>
#include "platform.hpp"

namespace gcn
{
    class GCN_CORE_DECLSPEC ListModel
    {
    public:
        virtual ~ListModel() { }
        virtual int getNumberOfElements() = 0;
        virtual std::string getElementAt(int i) = 0;
    };
}
