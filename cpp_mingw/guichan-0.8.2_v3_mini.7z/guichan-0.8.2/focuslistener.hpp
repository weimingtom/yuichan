#pragma once

#include <string>
#include "event.hpp"
#include "platform.hpp"

namespace gcn
{
    class GCN_CORE_DECLSPEC FocusListener
    {
    public:
        virtual ~FocusListener() { }
        virtual void focusGained(const Event& event) { };
        virtual void focusLost(const Event& event) { };
    protected:
        FocusListener() { }
    };
}
