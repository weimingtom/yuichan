#!/bin/sh

java -cp guichan.jar com.iteye.weimingtom.guichan.demo.fps.awt.FPSDemoExample

