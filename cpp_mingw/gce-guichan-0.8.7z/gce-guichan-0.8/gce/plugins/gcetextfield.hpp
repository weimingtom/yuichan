
#ifndef GCE_TEXTFIELD_HPP
#define GCE_TEXTFIELD_HPP

class gceTextField : public gcn::TextField
{
    public:
	void draw(gcn::Graphics *g);
	
}; 

#endif // end GCE_TEXTFIELD_HPP
