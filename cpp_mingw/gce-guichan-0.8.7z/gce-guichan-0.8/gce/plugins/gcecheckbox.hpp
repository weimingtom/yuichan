
#ifndef GCE_CHECKBOX_HPP
#define GCE_CHECKBOX_HPP



class gceCheckBox : public gcn::CheckBox
{
    public:
    void draw(gcn::Graphics *g);
};

#endif // end GCE_CHECKBOX_HPP

