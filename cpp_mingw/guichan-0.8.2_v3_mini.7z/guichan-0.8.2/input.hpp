#pragma once

#include "platform.hpp"

namespace gcn
{
    class KeyInput;
    class MouseInput;

    class GCN_CORE_DECLSPEC Input
    {
    public:
        virtual ~Input(){ }
        virtual bool isKeyQueueEmpty() = 0;
        virtual KeyInput dequeueKeyInput() = 0;
        virtual bool isMouseQueueEmpty() = 0;
        virtual MouseInput dequeueMouseInput() = 0;
        virtual void _pollInput() = 0;
    };
}
