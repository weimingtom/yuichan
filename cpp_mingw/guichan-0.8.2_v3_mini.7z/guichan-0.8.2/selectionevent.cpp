#include "selectionevent.hpp"

namespace gcn
{
    SelectionEvent::SelectionEvent(Widget* source)
            :Event(source)
    {

    }

    SelectionEvent::~SelectionEvent()
    {

    }
}

