#!/bin/sh

#source _setuppath.sh
#or
#. _setuppath.sh

export PATH=~/work/jdk1.7.0_80/bin:$PATH

