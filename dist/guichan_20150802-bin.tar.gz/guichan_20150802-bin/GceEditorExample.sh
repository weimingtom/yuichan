#!/bin/sh

java -cp guichan.jar com.iteye.weimingtom.guichan.gce.awt.GceEditorExample

