
#ifndef GCE_RADIOBUTTON_HPP
#define GCE_RADIOBUTTON_HPP



class gceRadioButton : public gcn::RadioButton
{
    public:
    void draw(gcn::Graphics *g);
};

#endif // end GCE_RADIOBUTTON_HPP

