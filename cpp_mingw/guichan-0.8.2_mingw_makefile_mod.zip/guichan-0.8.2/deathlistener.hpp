#pragma once

#include <string>
#include "event.hpp"
#include "platform.hpp"

namespace gcn
{
    class GCN_CORE_DECLSPEC DeathListener
    {
    public:
        virtual ~DeathListener() { }
        virtual void death(const Event& event) = 0;
    
    protected:
        DeathListener() { }
    };
}
