#!/bin/sh

java -cp guichan.jar com.iteye.weimingtom.guichan.example.awt.WidgetsExample

