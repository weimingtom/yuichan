
#ifndef GCE_SCROLLAREA_HPP
#define GCE_SCROLLAREA_HPP

class gceScrollArea : public gcn::ScrollArea 
{
	public:
	void draw(gcn::Graphics* g);

}; 

#endif // end GCE_SCROLLAREA_HPP
