#pragma once

#include <string>
#include <oglft.h>
#include "guichan/font.hpp"
#include "guichan/graphics.hpp"
#include "guichan/platform.hpp"

namespace gcn
{
    namespace contrib
    {
        class GCN_EXTENSION_DECLSPEC OGLFTFont: public Font
        {
        public:
            GLFont (const std::string& filename, int size);
            virtual ~GLFont();
            virtual void setRowSpacing (int spacing);
            virtual int getRowSpacing();
            virtual gcn::Color getColor();
            virtual void setColor(gcn::Color color);
            virtual int getWidth(const std::string& text) const;
            virtual int getHeight() const;
            virtual void drawString(Graphics* graphics, const std::string& text, int x, int y);

        protected:
            OGLFT::TranslucentTexture* mFont;
            std::string mFilename;
            gcn::Color mFontColor;
            int mSize;
            int mRowSpacing;
        };
    }
}
