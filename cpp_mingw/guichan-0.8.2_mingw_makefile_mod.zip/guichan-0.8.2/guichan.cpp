extern "C"
{
    const char* gcnGuichanVersion()
    {
        return "0.8";
    }
}
