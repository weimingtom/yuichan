This is a demo demonstrating Guichan and overloading of widgets 
to get a RPG look alike menu system.

For more information about Guchan visit:
http://guichan.sourceforge.net
