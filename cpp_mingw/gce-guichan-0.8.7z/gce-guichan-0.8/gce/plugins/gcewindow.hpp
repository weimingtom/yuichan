
#ifndef GCE_WINDOW_HPP
#define GCE_WINDOW_HPP

class gceWindow : public gcn::Window 
{
	public:
	void draw(gcn::Graphics* g);
	
}; 

#endif // end GCE_TEXTFIELD_HPP
