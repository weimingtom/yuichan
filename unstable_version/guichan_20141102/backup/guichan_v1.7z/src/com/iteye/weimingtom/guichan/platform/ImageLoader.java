package com.iteye.weimingtom.guichan.platform;

public abstract class ImageLoader {
	public Image load(String filename) {
		return load(filename, true);
	}
	
	public abstract Image load(String filename, boolean convertToDisplayFormat);
}
