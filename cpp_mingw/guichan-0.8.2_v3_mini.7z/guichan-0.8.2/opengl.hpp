#pragma once

#include "opengl/openglgraphics.hpp"
#include "opengl/openglimage.hpp"
#include "platform.hpp"

extern "C"
{
    GCN_EXTENSION_DECLSPEC extern void gcnOpenGL();
}
