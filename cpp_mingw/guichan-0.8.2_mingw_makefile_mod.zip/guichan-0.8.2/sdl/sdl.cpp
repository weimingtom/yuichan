#include "../sdl.hpp"

extern "C"
{
    void gcnSDL() { }
}
