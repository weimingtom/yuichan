This is a demo demonstrating Guichan and overloading of widgets to get an FPS
look alike menu system.

For more information about Guchan visit http://guichan.sourceforge.net
