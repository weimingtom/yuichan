package com.iteye.weimingtom.guichan.basic;

public class Guichan {
	private Guichan() {
		
	}
	
    public static String gcnGuichanVersion() {
        return "0.8.2";
    }
}
