#pragma once

#include "event.hpp"
#include "platform.hpp"

namespace gcn
{
    class Widget;

    class GCN_CORE_DECLSPEC SelectionEvent: public Event
    {
    public:
        SelectionEvent(Widget* source);
        virtual ~SelectionEvent();
    };
}
