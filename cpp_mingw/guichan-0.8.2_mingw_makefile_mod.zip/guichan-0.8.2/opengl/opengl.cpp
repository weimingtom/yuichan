#include "../opengl.hpp"

extern "C"
{
    void gcnOpenGL() { }
}
