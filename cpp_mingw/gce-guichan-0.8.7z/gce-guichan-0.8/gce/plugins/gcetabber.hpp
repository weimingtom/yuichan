
#ifndef GCE_TABBER_HPP
#define GCE_TABBER_HPP

class gceTabber : public gcn::TabbedArea 
{
	public:
	void draw(gcn::Graphics* g);
	
}; 

#endif // end GCE_TABBER_HPP
