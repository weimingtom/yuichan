#include "oglftfont.hpp"
#include "../exception.hpp"
#include "openglgraphics.hpp"

namespace gcn
{
    namespace contrib
    {
        OGLFTFont::OGLFTFont (const std::string& filename, int size)
        {
            mRowSpacing = 0;
            mFilename = filename;
            mFont = NULL;
            mSize = size;

            mFont = new OGLFT::TranslucentTexture(filename.c_str(), size, 72);

            if(mFont == NULL || !mFont->isValid())
            {
                throw GCN_EXCEPTION("Invalid True Type Font.");
            }

            glPixelStorei( GL_UNPACK_ALIGNMENT, 1 );

            mFontColor = gcn::Color(0, 0, 0, 0);
        }

        OGLFTFont::~OGLFTFont()
        {
            delete mFont;
        }

        int OGLFTFont::getWidth(const std::string& text) const
        {
            OGLFT::BBox bbox = mFont->measure(text.c_str());

            return (int)bbox.x_max_ + (int)bbox.x_min_;
        }

        int OGLFTFont::getHeight() const
        {
            return mSize - 1 + mRowSpacing;
        }

        void OGLFTFont::setRowSpacing(int spacing)
        {
            mRowSpacing = spacing;
        }

        int OGLFTFont::getRowSpacing()
        {
            return mRowSpacing;
        }

        gcn::Color OGLFTFont::getColor()
        {
            return mFontColor;
        }

        void OGLFTFont::setColor(gcn::Color color)
        {
            mFontColor = color;
        }

        void OGLFTFont::drawString(gcn::Graphics* graphics, const std::string& text, int x, int y)
        {
            if (text == "")
            {
                return;
            }

            gcn::OpenGLGraphics* glGraphics = dynamic_cast<gcn::OpenGLGraphics *>(graphics);

            if(glGraphics == NULL)
            {
                throw GCN_EXCEPTION("Graphics object not an OpenGL graphics object!");
            }

            const gcn::ClipRectangle& top = glGraphics->getCurrentClipArea();

            mFont->setForegroundColor(mFontColor.r/255, mFontColor.g/255, mFontColor.b/255);

            glPushMatrix();
            glEnable(GL_TEXTURE_2D);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

            glTranslated(x + top.xOffset, y + top.yOffset + (mSize/2)+5, 0.);
            glRotatef(180., 1., 0., 0.);

            mFont->draw(text.c_str());

            glDisable(GL_BLEND);
            glDisable(GL_TEXTURE_2D);
            glPopMatrix();
        }
    }
}
