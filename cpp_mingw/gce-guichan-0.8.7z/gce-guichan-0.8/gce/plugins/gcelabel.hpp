
#ifndef GCE_LABEL_HPP
#define GCE_LABEL_HPP



class gceLabel : public gcn::Label
{
    public:
    void draw(gcn::Graphics *g);
};

#endif // end GCE_LABEL_HPP

