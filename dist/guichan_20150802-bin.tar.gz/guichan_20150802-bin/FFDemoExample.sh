#!/bin/sh

java -cp guichan.jar com.iteye.weimingtom.guichan.demo.ff.awt.FFDemoExample

